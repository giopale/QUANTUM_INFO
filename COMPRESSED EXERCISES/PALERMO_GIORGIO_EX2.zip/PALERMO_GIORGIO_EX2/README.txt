PALERMO GIORGIO - EX2

The code is contained in the DMatrixCODE.f03 file.

To compile:
gfortran DMatrixCODE.f03 -o DMatrixCODE.out



