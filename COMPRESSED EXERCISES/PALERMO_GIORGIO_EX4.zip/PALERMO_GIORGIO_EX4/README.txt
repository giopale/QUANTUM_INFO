Giorgio Palermo - EX4

Fortran subroutines and program -> cos.f90
Python script -> program.py
gnuplot script -> plotres.gp

To run -> put all in the same folder and run the python script.